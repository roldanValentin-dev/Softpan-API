---
name: Artisanal Pâtisserie Narrative
colors:
  surface: '#fef8f3'
  surface-dim: '#ded9d4'
  surface-bright: '#fef8f3'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f8f3ee'
  surface-container: '#f2ede8'
  surface-container-high: '#ece7e2'
  surface-container-highest: '#e6e2dd'
  on-surface: '#1d1b19'
  on-surface-variant: '#4f4540'
  inverse-surface: '#32302d'
  inverse-on-surface: '#f5f0eb'
  outline: '#81746f'
  outline-variant: '#d3c3bd'
  surface-tint: '#72594d'
  primary: '#100401'
  on-primary: '#ffffff'
  primary-container: '#2d1b12'
  on-primary-container: '#9d8174'
  inverse-primary: '#e0c0b1'
  secondary: '#755b00'
  on-secondary: '#ffffff'
  secondary-container: '#fed977'
  on-secondary-container: '#785d00'
  tertiary: '#110400'
  on-tertiary: '#ffffff'
  tertiary-container: '#361700'
  on-tertiary-container: '#b97848'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#fddccd'
  primary-fixed-dim: '#e0c0b1'
  on-primary-fixed: '#29170f'
  on-primary-fixed-variant: '#584237'
  secondary-fixed: '#ffe08f'
  secondary-fixed-dim: '#e6c364'
  on-secondary-fixed: '#241a00'
  on-secondary-fixed-variant: '#584400'
  tertiary-fixed: '#ffdcc5'
  tertiary-fixed-dim: '#ffb783'
  on-tertiary-fixed: '#301400'
  on-tertiary-fixed-variant: '#6c3a0e'
  background: '#fef8f3'
  on-background: '#1d1b19'
  surface-variant: '#e6e2dd'
typography:
  display-lg:
    fontFamily: Playfair Display
    fontSize: 48px
    fontWeight: '700'
    lineHeight: '1.1'
    letterSpacing: -0.02em
  display-lg-mobile:
    fontFamily: Playfair Display
    fontSize: 36px
    fontWeight: '700'
    lineHeight: '1.2'
  headline-md:
    fontFamily: Playfair Display
    fontSize: 32px
    fontWeight: '600'
    lineHeight: '1.3'
  body-lg:
    fontFamily: DM Sans
    fontSize: 18px
    fontWeight: '400'
    lineHeight: '1.6'
  body-md:
    fontFamily: DM Sans
    fontSize: 16px
    fontWeight: '400'
    lineHeight: '1.5'
  decorative-sm:
    fontFamily: Caveat
    fontSize: 22px
    fontWeight: '400'
    lineHeight: '1.2'
  label-caps:
    fontFamily: DM Sans
    fontSize: 12px
    fontWeight: '700'
    lineHeight: '1'
    letterSpacing: 0.1em
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  unit: 8px
  container-max: 1120px
  gutter: 24px
  margin-mobile: 16px
  section-padding: 80px
---

## Brand & Style

The design system is built upon the concept of a "living recipe book," blending the elegance of French pastry techniques with the rustic, sun-drenched warmth of Tucumán. The visual language avoids the sterile perfection of modern SaaS interfaces in favor of an **Artisanal/Tactile** style that feels human, intentional, and slightly imperfect.

The emotional goal is to evoke the scent of browned butter and the texture of flour. This is achieved through:
- **Hand-Drawn Details:** Every structural element (dividers, underlines, borders) should look as if it were sketched with a fine-liner pen.
- **Organic Movement:** Icons and decorative flourishes are custom illustrations with slight variations in stroke weight to mimic hand-drawing.
- **Warmth:** A high-saturation, low-contrast approach to color that feels inviting rather than clinical.

## Colors

The palette is inspired by raw pastry ingredients: flour, dark chocolate, caramel, and gold leaf. 

- **Background (#fdf8f3):** Use this for the main canvas to reduce eye strain and provide a "paper" feel.
- **Primary (#2d1b12):** Reserved for high-priority text and heavy hand-drawn strokes. It provides the necessary grounding for the lighter pastels.
- **Accents:** Use **Gold (#c9a84c)** for celebratory moments and CTAs, **Caramel (#c17f4e)** for interactive hover states and links, and **Pastel Pink (#d4a5a5)** for soft highlights, chips, or background shapes behind product photography.

## Typography

This design system utilizes a trio of typefaces to establish a clear hierarchy of intent:
1. **Playfair Display:** Used for headers to signal elegance and the French heritage of the craft.
2. **DM Sans:** A modern, highly legible sans-serif for body text and functional interface elements, ensuring the "artisanal" vibe doesn't compromise usability.
3. **Caveat:** A decorative secondary layer. Use this for "hand-written" notes, price tags, ingredients, or small side-comments in the UI to reinforce the personal, chef-to-customer connection.

**Note:** Never use Caveat for long paragraphs. It should be treated as an illustrative element.

## Layout & Spacing

The layout follows a **Fixed Grid** approach on desktop to mimic the centered, structured nature of a physical cookbook. 

- **Grid:** 12-column layout with generous 24px gutters.
- **Rhythm:** Use multiples of 8px for spacing. However, intentionally break the grid slightly with decorative elements (like a "stray" hand-drawn star or a leaf) to maintain the organic feel.
- **White Space:** Prioritize large vertical margins (80px+) between sections to allow the high-quality food photography to breathe.
- **Mobile:** Transition to a single-column layout with 16px margins, maintaining the centered alignment for headings.

## Elevation & Depth

This design system rejects digital-first shadows in favor of **Tonal Layers** and **Physical Outlines**.

- **Shadows:** Avoid using standard CSS box-shadows. If depth is required, use a "double border" technique or a hard, offset "drop shadow" stroke (2px offset, 100% opacity) in a muted secondary color to simulate a paper cutout.
- **Tiers:** 
  - **Level 0 (Base):** Warm Cream (#fdf8f3).
  - **Level 1 (Cards):** Pure White (#ffffff) with a thin, 1px hand-drawn style border in #8b7355.
- **Dividers:** Use hand-drawn "dotted" lines or rough pen-stroke lines instead of solid 1px gray lines.

## Shapes

The shape language is **Soft and Organic**. 

- **Corners:** Use 0.5rem (8px) for standard components and 1rem (16px) for larger cards. 
- **The "Wobbly" Border:** Whenever possible, use an SVG mask or a border-image that introduces a slight "wobble" to straight lines, preventing them from looking perfectly mechanical.
- **Buttons:** Should be fully rounded (pill-shaped) or have a high corner radius to feel "soft" to the touch.

## Components

### Buttons
Primary buttons use the Gold (#c9a84c) fill with Primary Text (#2d1b12). Secondary buttons use a hand-drawn outline with no fill. All buttons should have a subtle "pressed" animation that slightly shifts the element 2px down and to the right.

### Cards
Cards for pastry items should be White (#ffffff). The product image should be at the top, followed by a Playfair Display title. Use the **Caveat** font for the price to make it look handwritten by the baker.

### Input Fields
Inputs should not be fully enclosed boxes. Use a "bottom-border only" style using a hand-drawn stroke. The label should use **DM Sans (label-caps)**.

### Custom Elements
- **Hand-drawn Underlines:** Use a custom SVG squiggle for hover states on links rather than a standard straight underline.
- **Dotted Textures:** Use a repeating dot pattern (1px dots, 8px apart) in #8b7355 for background accents or card headers to add textural depth.
- **Stamp:** A circular "Artisanal" seal illustration should be used as a watermark or floating element on key product images.